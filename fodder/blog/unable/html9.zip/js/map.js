// -------------------------------------------------------------
    //   Google Map
    // -------------------------------------------------------------  

    (function(){
        var map;

        map = new GMaps({
            el: '#gmap',
            lat: 36.5690613,
            lng: 53.0661700,
            scrollwheel:false,
            zoom: 16,
            zoomControl : true,
            panControl : true,
            streetViewControl : true,
            mapTypeControl: false,
            overviewMapControl: true,
            clickable: false
        });

        var image = '';
        map.addMarker({
            lat: 36.5690613,
            lng: 53.0661700,
            icon: image,
            animation: google.maps.Animation.DROP,
            verticalAlign: 'bottom',
            horizontalAlign: 'center',
            backgroundColor: '#d3cfcf',
        });


        var styles = [ 

        {
            "featureType": "road",
            "stylers": [
            { "color": "#dddddd" }
            ]
        },{
            "featureType": "water",
            "stylers": [
            { "color": "#cecece" }
            ]
        },{
            "featureType": "landscape",
            "stylers": [
            { "color": "#efefef" }
            ]
        },{
            "elementType": "labels.text.fill",
            "stylers": [
            { "color": "#555555" }
            ]
        },{
            "featureType": "poi",
            "stylers": [
            { "color": "#cfcfcf" }
            ]
        },{
            "elementType": "labels.text",
            "stylers": [
            { "saturation": 1 },
            { "weight": 0.1 },
            { "color": "#848484" }
            ]
        }

        ];

        map.addStyle({
            styledMapName:"Styled Map",
            styles: styles,
            mapTypeId: "map_style"  
        });

        map.setStyle("map_style");
    }()); 